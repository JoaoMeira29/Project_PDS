import { Component } from '@angular/core';

@Component({
  selector: 'app-pag-not-found',
  templateUrl: './pag-not-found.component.html',
  styleUrls: ['./pag-not-found.component.css']
})
export class PagNotFoundComponent {

}

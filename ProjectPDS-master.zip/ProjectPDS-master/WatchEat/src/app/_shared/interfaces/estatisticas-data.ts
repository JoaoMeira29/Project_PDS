export interface EstatisticasData {
  bestCont: any[];
  worstCont: any[];
  contMediaRating: any[];
  top5Genres: any[];
}
